"""CD Chat client program"""
import fcntl
import logging
import os
import sys
import selectors
import socket

from .protocol import CDProto, CDProtoBadFormat

HOST="127.0.0.1" # Standard loopback interface address (localhost)
PORT= 5555 # Tem que ser o mesmo do server

logging.basicConfig(filename=f"{sys.argv[0]}.log", level=logging.DEBUG)


class Client:
    """Chat Client process."""

    def __init__(self, name: str = "Foo"):
        """Initializes chat client."""
        self.name = name
        self.clientsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.addr = (HOST, PORT)
        self.sel=selectors.DefaultSelector()
        self.channel= None
        

    def connect(self):
        """Connect to chat server and setup stdin flags."""
        self.clientsock.connect(self.addr) 
        self.sel.register(self.clientsock, selectors.EVENT_READ, self.receive)
        msg = CDProto.register(self.name)
        CDProto.send_msg(self.clientsock ,msg)
        logging.debug("send %s", msg)


 

    def receive(self, conn, mask):
        msg_received=CDProto.recv_msg(conn) 
        if msg_received.command == "message":
            logging.debug('received "%s', msg_received.message) 
        
        print(msg_received.message)
    

 

    def got_keyboard_data(self,stdin, mask):

        input_msg = stdin.read().rstrip("\n")
        w = input_msg.split(" ")
 

        if(w[0] == "exit"):
            self.sel.unregister(self.clientsock)
            self.clientsock.close()
            sys.exit(f"Until next time {self.name}!")

 

        elif(w[0] == "/join" and len(w) == 2):
            self.channel = w[1]
            CDProto.send_msg(self.clientsock, CDProto.join(self.channel))
            logging.debug("sent %s", CDProto.join(self.channel))

 
        else:
            msg = CDProto.message(input_msg, self.channel)
            CDProto.send_msg(self.clientsock, msg) # client -> server
            logging.debug("sent %s", msg)

    def loop(self):
        """Loop indefinetely."""
        orig_fl = fcntl.fcntl(sys.stdin, fcntl.F_GETFL)
        fcntl.fcntl(sys.stdin, fcntl.F_SETFL, orig_fl | os.O_NONBLOCK)
        self.sel.register(sys.stdin, selectors.EVENT_READ, self.got_keyboard_data)
        

        while True:
            events = self.sel.select()
            for k, mask in events:
                callback = k.data
                callback(k.fileobj, mask)
