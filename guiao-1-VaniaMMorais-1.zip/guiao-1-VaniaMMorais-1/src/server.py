"""CD Chat server program."""
import logging
import selectors
import socket


from src.protocol import CDProto, CDProtoBadFormat, TextMessage
from collections import defaultdict

HOST="127.0.0.1" # Standard loopback interface address (localhost)
PORT= 5555 # Tem que ser o mesmo do client

logging.basicConfig(filename="server.log", level=logging.DEBUG)


class Server:
    """Chat Server process."""

    def __init__(self):
        self.serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sel = selectors.DefaultSelector()
        self.serversocket.bind((HOST, PORT))
        self.serversocket.listen()
        self.sel.register(self.serversocket, selectors.EVENT_READ, self.accept)
        self.channels = defaultdict(list)           # canais de chat  {conn : [canal1, canal2, canal 3]}
        self.channels["canal"] = []

        
    def accept(self, conn, mask):
        conn, addr = self.serversocket.accept()  # Should be ready
        conn.setblocking(False)
        self.sel.register(conn, selectors.EVENT_READ, self.read)

    def read(self, conn, mask):
        data = CDProto.recv_msg(conn)  # Should be ready
        logging.debug("received %s", data)
        if data:
            if data.command == "register":
                self.channels["canal"].append(conn)

            if data.command == "message":
                channel=data.channel if data.channel else "canal"
                for client in self.channels[channel]:
                    CDProto.send_msg(client, data)
                    logging.debug("send %s", data)
            
            if data.command == "join":
                channel=data.channel
                if(channel in self.channels):
                    self.channels[channel].append(conn)
                else:
                    self.channels[channel] = [conn]   
        else:
            self.sel.unregister(conn)
            for clients in self.channels.values():
                if conn in clients:
                    clients.remove(conn)
            conn.close()

    def loop(self):
        """Loop indefinetely."""
        while True:
            events = self.sel.select()
            for key, mask in events:
                callback = key.data
                callback(key.fileobj, mask)

