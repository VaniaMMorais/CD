# cd_chat_server

This is a template repository for Computação Distribuida assignment 1

## How to execute tests locally

- Install requirements
```bash
$ pip install -r requirements.txt
```
- Run tests:
```bash
$ pytest
