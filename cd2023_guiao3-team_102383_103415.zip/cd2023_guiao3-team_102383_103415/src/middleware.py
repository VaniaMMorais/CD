"""Middleware to communicate with PubSub Message Broker."""
from collections.abc import Callable
from enum import Enum
from queue import LifoQueue, Empty
from typing import Any
import socket
import json
import pickle
import xml.etree.ElementTree as ET
import time

from .protocol import MBProtocol, MBProtocolBadFormat


class MiddlewareType(Enum):
    """Middleware Type."""

    CONSUMER = 1
    PRODUCER = 2


class Queue:
    """Representation of Queue interface for both Consumers and Producers."""

    def __init__(self, topic, _type=MiddlewareType.CONSUMER):
        """Create Queue."""
        self.middleware_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.host="127.0.0.1" # Standard loopback interface address (localhost)
        self.port=5000
        self._type = _type
        self.topic = topic
        self.middleware_sock.connect((self.host, self.port))



        MBProtocol.send_msg(self.middleware_sock, 0, MBProtocol.register(0))

    def push(self, value):
        """Sends data to broker."""
        MBProtocol.send_msg(self.middleware_sock, self.serialization_type , MBProtocol.pub(self.topic, value))


    def pull(self): #-> (str, Any):
        """Receives (topic, data) from broker.

        Should BLOCK the consumer!"""
        sms = MBProtocol.recv_msg(self.middleware_sock)  #ERRO
        if sms.type == "Publish":
            return sms.topic, sms.value
        else:
            return None, None

    def list_topics(self, callback: Callable):
        """Lists all topics available in the broker."""
        MBProtocol.send_msg(self.middleware_sock, self.serialization_type, MBProtocol.list())
        callback(MBProtocol.recv_msg(self.middleware_sock))


    def cancel(self):
        """Cancel subscription."""
        MBProtocol.send_msg(self.middleware_sock, self.serialization_type, MBProtocol.unsub(self.topic))


class JSONQueue(Queue):
    """Queue implementation with JSON based serialization."""
    def __init__(self, topic, _type=MiddlewareType.CONSUMER):
        super().__init__(topic, _type)
        self.serialization_type = 0
        if _type == MiddlewareType.CONSUMER:
            MBProtocol.send_msg(self.middleware_sock, 0, MBProtocol.sub(self.topic))
            

    def pull(self):
        super().pull()
        

    def push(self, value):
        super().push(value)

    def cancel():
        super().cancel()

    def list_topics(self, callback):
        super().list_topics(callback)


class XMLQueue(Queue):
    """Queue implementation with XML based serialization."""
    def __init__ (self,topic, _type=MiddlewareType.CONSUMER):
        super().__init__(topic,_type)
        self.serialization_type = 1
        if _type == MiddlewareType.CONSUMER:
            MBProtocol.send_msg(self.middleware_sock, 1, MBProtocol.sub(self.topic))

    def pull(self):
        super().pull()

    def push(self, value):
        super().push(value)

    def cancel():
        super().cancel()

    def list_topics(self, callback):
        super().list_topics(callback)


class PickleQueue(Queue):
    """Queue implementation with Pickle based serialization."""
    def __init__ (self,topic, _type=MiddlewareType.CONSUMER):
        super().__init__(topic,_type)
        self.serialization_type = 2
        if _type == MiddlewareType.CONSUMER:
            MBProtocol.send_msg(self.middleware_sock, 2, MBProtocol.sub(self.topic))

    def pull(self):
        super().pull()

    def push(self, value):
        super().push(value)

    def cancel():
        super().cancel()

    def list_topics(self, callback):
        super().list_topics(callback)
