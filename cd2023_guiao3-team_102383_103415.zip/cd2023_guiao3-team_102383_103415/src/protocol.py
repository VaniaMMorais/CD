import json
import json.decoder
import pickle
from pydoc_data.topics import topics
import xml.etree.ElementTree as et
import time
from datetime import datetime
from socket import socket, timeout
from typing import SupportsBytes
import enum
import errno

class Serializer(enum.Enum):
    """Possible message serializers."""

    JSON = 0
    XML = 1
    PICKLE = 2




class Message:
    """Message Type."""

    def __init__(self, type):
        self.type = type

    


class Publish(Message):
    def __init__(self, topic, value):
        super().__init__("Publish")
        self.topic = topic
        self.value= value

    def __str__(self):
        return f'{{"Type": "{self.type}", "Topic": "{self.topic}", "Value": {self.value}}}'

    def pickle(self):
        return {"Type": self.type, "Topic": self.topic, "Value": self.value}

    def xml(self):
        return "<?xml version=\"1.0\"?><data Type=\"{}\" Topic=\"{}\" Value=\"{}\"></data>".format( self.type, self.topic, self.value )



class Subscribe(Message):
    def __init__(self, topic):
        super().__init__("Subscribe")
        self.topic = topic
    
    def __str__(self):
        return f'{{"Type": "{self.type}", "Topic": "{self.topic}"}}'

    def pickle(self):
        return {"Type": self.type, "Topic": self.topic}

    def xml(self):
        return "<?xml version=\"1.0\"?><data Type=\"{}\" Topic=\"{}\"></data>".format( self.type, self.topic )



    
class ListMessage(Message):
    def __init__(self, lst):
        super().__init__("List")
        self.lst=lst
    
    def __str__(self):
        return f'{{"Type": "{self.type}", "List": "{self.lst}"}}'

    def pickle(self):
        return {"Type": self.type, "List": self.list}

    def xml(self):
        return "<?xml version=\"1.0\"?><data Type=\"{}\" List=\"{}\"></data>".format( self.type, self.lst )



class UnSub(Message):
    def __init__(self, topic):
        super().__init__("UnSubscribe")
        self.topic = topic
    
    def __str__(self):
        return f'{{"Type": "{self.type}", "Topic": "{self.topic}"}}'

    def pickle(self):
        return {"Type": self.type, "Topic": self.topic}

    def xml(self):
        return "<?xml version=\"1.0\"?><data Type=\"{}\" Topic=\"{}\"></data>".format( self.type, self.topic )

class Register(Message):
    def __init__(self, lang):
        super().__init__("Register")
        self.lang = lang
    
    def __str__(self):
        return f'{{"Type": "{self.type}", "Lang": {self.lang}}}'
    
    def pickle(self):
        return {"Type": self.type, "Lang": self.lang}
    
    def xml(self):
        return "<?xml version=\"1.0\"?><data Type=\"{}\" Lang=\"{}\"></data>".format( self.type, self.lang )

class MBProtocol:

    @classmethod
    def sub(cls, topic) -> Subscribe:
        return Subscribe(topic)

    @classmethod
    def pub(cls, topic, value) -> Publish:
        return Publish(topic, value)

    @classmethod
    def list(cls, lst) -> ListMessage:
        return ListMessage(lst)

    @classmethod
    def unsub(cls, topic) -> UnSub:
        return UnSub(topic)

    @classmethod
    def register(cls, lang) -> Register:
        return Register(lang)

    @classmethod
    def send_msg(cls, connection: socket, coding, msg: Message):
        
        if (coding == 0 or str(coding) == str(Serializer.JSON)):
            dic = json.loads(msg.__str__())
            encoded_msg = json.dumps(dic).encode('utf-8')
            #connection.send(len(temp).to_bytes(2, 'big'))
            #connection.send(temp)
            #encoded_msg =  json.dumps(msg.__dict__).encode('utf-8')
            #print (msg.__dict__)
            print (dic)
        elif (coding == 1 or str(coding) == str(Serializer.XML)):
            root = et.Element('root')
            et.SubElement(root,'message').set("value",str(msg))
            encoded_msg = et.tostring(root)
        elif (coding == 2 or str(coding) == str(Serializer.PICKLE)):
            encoded_msg = pickle.dumps(msg)
            
        header = len(encoded_msg).to_bytes(2, 'big')
        
        
        # header = str(len(encoded_msg))    
        # print(header)                           
        # size_header = len(header) 
        # print(size_header)                              
        # newheader= 'f'*(4-size_header) + header 
        # print(newheader)
        try:
            connection.send(header + encoded_msg)
        except:#ConnectionResetError:
            # print("==> ConnectionResetError")
            pass
        # except timeout: 
        #     print("==> Timeout")
        #     pass

    @classmethod
    def recv_msg(cls, connection: socket): # -> Message:
        #coding = int.from_bytes(connection.recv(1), "big")
        headerB = connection.recv(2)
        header = int.from_bytes(headerB,'big')
        data = connection.recv(header)
        coding = int.from_bytes(connection.recv(1), 'big')
        print("data",data)
        
        if data: 
            # header = int(header.decode('utf-8').replace('f',''))    
            # data = connection.recv(header)
            # print("header is this ", header, " and this is coding ", coding)
            try:
                #print(coding)
                #print(type(coding))
                #print(Serializer.JSON)
                #print(coding == Serializer.JSON)
                #print(coding == 0)

                if coding == 0:  # or coding == None:
                    datadecoded = data.decode("utf-8")
                    msg2 = json.loads(datadecoded)
                elif coding == 1:
                    Xml_et = et.fromstring(data.decode('utf-8'))
                    msg2 = Xml_et.find('message').attrib('value')
                elif coding == 2:
                    msg2 = pickle.loads(data)

                
                if msg2["Type"] == "Subscribe":  
                    return cls.sub(msg2["topic"])
                
                elif msg2["Type"] == "Publish":
                    return cls.pub(msg2["Topic"], msg2["Value"])
                
                elif msg2["Type"] == "List":
                    return cls.list(msg2["List"])

                elif msg2["Type"] == "UnSubscribe":
                    return cls.unsub(msg2["Topic"])
                
                else:
                    return None

            except:  
                # json.JSONDecodeError: #as err:
                raise MBProtocolBadFormat()
            


class MBProtocolBadFormat(Exception):
    """Exception when source message is not MBPortocolBadFormat."""

    def __init__(self, original_msg: bytes=None) :
        """Store original message that triggered exception."""
        self._original = original_msg

    @property
    def original_msg(self) -> str:
        """Retrieve original message as a string."""
        return self._original.decode("utf-8")