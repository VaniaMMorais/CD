"""Message Broker"""
from ast import Delete
import enum
import json
from typing import Dict, List, Any, Tuple
import socket
import selectors
from src.protocol import MBProtocol, MBProtocolBadFormat


class Serializer(enum.Enum):
    """Possible message serializers."""

    JSON = 0
    XML = 1
    PICKLE = 2


class Broker:
    """Implementation of a PubSub Message Broker."""

    def __init__(self):
        """Initialize broker."""
        self.canceled = False
        self.host = "127.0.0.1"
        self.port = 5000
        self.brokersocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.brokersocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sel = selectors.DefaultSelector()
        self.brokersocket.bind((self.host, self.port))
        self.brokersocket.listen()
        self.sel.register(self.brokersocket, selectors.EVENT_READ, self.accept)

        
        self.conn_serializer = {}     # { conn : serializer }
        self.topic_last_msg = {}    # { topic : mensagem recente}
        self.topic_users = {}   # { topic : [   , ...]}
        self.topics_list = set()

    def accept(self, sock, mask):
        conn, addr = sock.accept()
        headerB = conn.recv(2)
        header = int.from_bytes(headerB,'big')
        data = json.loads(conn.recv(header))
        print(data)
        serialization_type = data['Lang']
        if (serialization_type == "JSONQueue" or serialization_type == 0):
            self.conn_serializer[conn] = Serializer.JSON
        elif (serialization_type == "XMLQueue" or serialization_type == 1):
            self.conn_serializer[conn] = Serializer.XML
        elif (serialization_type == "PickleQueue" or serialization_type == 2):
            self.conn_serializer[conn] = Serializer.PICKLE
        self.sel.register(conn, selectors.EVENT_READ, self.read)

    def read(self,conn,mask):
        if conn not in self.conn_serializer:
            header = conn.recv(2).decode('UTF-8') 
            header_size = int(header)
            serialization_type = str(conn.recv(header_size).decode('UTF-8'))    #this received message has the serialization type of the consumer
            if (serialization_type == "JSONQueue"):
                self.conn_serializer[conn] = Serializer.JSON
            elif (serialization_type == "XMLQueue"):
                self.conn_serializer[conn] = Serializer.XML
            elif (serialization_type == "PickleQueue"):
                self.conn_serializer[conn] = Serializer.PICKLE

        sms = MBProtocol.recv_msg(conn ) #self.conn_serializer[conn]

        if sms:
            if sms.type == "Subscribe":
                self.subscribe(sms.topic,conn, self.conn_serializer[conn])
            
            elif sms.type == "Publish":
                self.put_topic(sms.topic,sms.value)
                if sms.topic in self.topic_users.keys():
                    for sub in self.topic_users[sms.topic]:
                        MBProtocol.send_msg(sub, self.conn_serializer[sub], MBProtocol.pub(sms.topic, self.get_topic(sms.topic)))

            elif sms.type == "List":
                MBProtocol.send_msg(conn, self.conn_serializer[conn], MBProtocol.list(self.list_topics()))
            elif sms.type == "UnSubscribe":
                self.unsubscribe(sms.topic, conn)


    def list_topics(self) -> List[str]:
        """Returns a list of strings containing all topics containing values."""
        lst = []
        for topic in self.topic_last_msg.keys():
            print(topic)
            lst.append(topic)
        return lst

    def get_topic(self, topic):
        """Returns the currently stored value in topic."""
        if topic in self.topic_last_msg:
            return self.topic_last_msg[topic]
        return None

    def put_topic(self, topic, value):
        """Store in topic the value."""
        if topic in self.topic_last_msg.keys():
            self.topic_last_msg.update({topic: value})
        else:
            self.topic_last_msg[topic] = value
        
        self.topics_list.add(topic)

        print(f'\n>> The topic {topic} has a new message: {value}')

    def list_subscriptions(self, topic: str) -> List[Tuple[socket.socket, Serializer]]:
        """Provide list of subscribers to a given topic."""
        return self.topic_users[topic]

    def subscribe(self, topic: str, address: socket.socket, _format: Serializer = None):
        """Subscribe to topic by client in address."""
        if address in self.conn_serializer.keys():
            self.conn_serializer.update({address: _format})
        else:
            self.conn_serializer[address] = _format

        self.topics_list.add(topic)

        if topic in self.topic_users.keys():
            self.topic_users[topic].append((address, _format))
        else: 
            self.topic_users[topic] = [(address, _format)]

        print( self.topic_users)
        msg = MBProtocol.sub(topic)
        MBProtocol.send_msg(address, _format, msg)

    def unsubscribe(self, topic, address):
        """Unsubscribe to topic by client in address."""
        format = self.conn_serializer[address]
        if topic in self.topic_users:
            self.topic_users[topic].remove((address, format))

    def run(self):
        """Run until canceled."""
        while not self.canceled:
            events = self.sel.select()
            for key, mask in events:
                callback = key.data
                callback(key.fileobj, mask) 
